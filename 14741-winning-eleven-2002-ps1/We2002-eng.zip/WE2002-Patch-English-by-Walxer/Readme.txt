Winning Eleven 2002 Names Patch 0.8
-----------------------------------

Version : 0.8
Release Date : 01/05/2002
CopyRight 2002 by Walxer

......................................................................
This is an UNOFFICIAL Patch and nor I nor Konami are liable of any
possible damages caused from it. This patch is copyrighted and
only the author can change it; anyway, you're allowed to spread it
freely among your friends, and if you plan to put it in your Web page,
at least e-mail me.
Winning Eleven 2002 is a copyrighted and copy-protected game, and 
this patch can be only used to make a personal backup copy.
......................................................................

This patch has be done to help all of the non-Japanease video-gamers
of the World, and what it does is translate most of the player names,
team names, and menu options from Japanease to English.
My work is still in progress, so my final goal has not been realized
at all.
My patch change the following things (between parenthesis there is
the completion percentage) :

- Nationals player names (100%)
- Master League player names (100%)
- Stadium names (0%)
- Team names on menu, team selections, results list, etc.. (100%)
- Call Names of the players (0%)
- Real player properties (1%)
- Main menu options (100%)
- Match menu options (100%)
- Titlings (75%)
- Other menus (90%)

Known Bugs:
-----------

- Often you'll se many team names, player names, call names in English
  but brutely truncated. For example: 
  Sala -> Sal, Juventus -> Juvent, Van Kerckhoven -> V.Kerckhov, ecc...
  Sorry but I can't do anything, those names are stored in a fixed
  length and in Japanease are almost ever much short and it can't be
  streched out (tecnically, those names is stored in multiplies of 
  4 bytes according to the word length, with last byte left to zero
  because it means the end; we'll obtain for example:

  Boban -> 42 6F 62 67 6E 00 00 00
          |--4 bytes--|--4 bytes--| 

  Sal -> 53 61 6C 00
        |--4 bytes--|


  If player name Sala in Japanease is stored in 3 characters, then
  it must fill 4 bytes (3 + 1 zero), but for us it should be other 4
  bytes long (4 + 4 zeroes), but this is fisically impossible!)
 

Conclusions
-----------

To use the patch read carefully the instructions reported on file
'Usage.txt'. If you'll find wrong names (and not only), send me 
immediately an e-mail; and if you know other player names I haven't, 
YOU SHOULD contact me!
For any suggestion, comment, malfunction you know what to do.

Thanks
------

- Walxer (walxer@tiscalinet.it)
  for the latest news, visit my web site:
  http://walxer.da.ru  

- WEndetta Forum (http://walxerforum.da.ru),
  for the affection, the support, the many helps, and all other a group of
  friends can give.

- Gran (gran77@tin.it),
  for giving me ALL game player names, also hidden ones. At final he translate
  Master League menus and some others in menu Edit.

- EvilGab (evil_gab@yahoo.it),
  for kindly send me all team game names.

- Olyone (olyone@libero.it) - Nandogrifo (nandogrifo@tin.it),
  for lending me the original CD game.

- Rob23 (tinio78@yahoo.it), 
  for have found a Memory Card with some names taken from a Chinese site.


We Are Football Tribe!

Walxer
------
E-Mail : walxer@tiscalinet.it
Web : http://walxer.da.ru